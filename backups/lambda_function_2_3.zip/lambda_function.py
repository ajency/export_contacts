import json
import signal
import os,sys,time,csv,datetime,platform
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By


nextEmailCredIndex = 0
nextLinkedInCredIndex = 0
email_credentials = [
	{"username": "pnitin3103@gmail.com", "password": "ajency#123"},
	{"username": "stinfordpaulie18@yahoo.com", "password": "ajency#123"},		#microsoft outlook & yahoo
	{"username": "stinfordpaulie18@aol.com", "password": "ajency#123"},			#aol
	{"username": "alina.jose1102@gmail.com", "password": "ajency#123"},			#gmail
]

linkedin_credentials = [
	{"username": "pnitin3103@gmail.com", "password": "ajency#123"},
	{"username": "alina.jose1102@gmail.com", "password": "ajency#123"},
]

def lambda_handler(event=None, context=None):
	global email_credentials
	global linkedin_credentials
	global nextLinkedInCredIndex

	# Program Execution
	select_different_linked_in_account(nextLinkedInCredIndex)
	print("Execution Completed")
	sys.exit()



# Initialize Driver & login into LinkedIn
def select_different_linked_in_account(nextLinkedInCredIndex):
	# operating system 
	driver_path = "assets/chrome_driver/chromedriver"
	headless_chromium_path = "/assets/chrome_driver/headless-chromium"

	# Headless Browser
	print("Running in Headless browser mode..")
	chrome_options = webdriver.ChromeOptions()
	chrome_options.add_argument('--headless')
	chrome_options.add_argument('--disable-gpu')
	chrome_options.add_argument('--disable-dev-shm-usage')
	chrome_options.add_argument('--window-size=1920,1080')
	chrome_options.add_argument('--no-sandbox') # required when running as root user. otherwise you would get no sandbox errors. 
	# chrome_options.add_argument('user-agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36')
	chrome_options.add_argument("user-agent=Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36")
	chrome_options.add_argument('--single-process')
	chrome_options.binary_location = os.getcwd() + headless_chromium_path

	# chrome_options.add_argument('--window-size=1280x1696')
	# chrome_options.add_argument('--user-data-dir=/tmp/user-data')
	# chrome_options.add_argument('--hide-scrollbars')
	# chrome_options.add_argument('--enable-logging')
	# chrome_options.add_argument('--log-level=0')
	# chrome_options.add_argument('--v=99')
	# chrome_options.add_argument('--data-path=/tmp/data-path')
	# chrome_options.add_argument('--ignore-certificate-errors')
	# chrome_options.add_argument('--homedir=/tmp')
	# chrome_options.add_argument('--disk-cache-dir=/tmp/cache-dir')

	driver = webdriver.Chrome(executable_path=driver_path, chrome_options=chrome_options)
	switch_to_linkedin_account(driver, nextLinkedInCredIndex)
	logout_from_linkedin(driver)



def switch_to_linkedin_account(driver, nextCredIndex=0):
	global email_credentials
	global linkedin_credentials
	global nextEmailCredIndex
	global nextLinkedInCredIndex
	linkedinUsername = linkedin_credentials[nextCredIndex]['username']
	linkedinPassword = linkedin_credentials[nextCredIndex]['password']
	login_to_linkedin(driver, linkedinUsername, linkedinPassword)
	nextLinkedInCredIndex = nextCredIndex + 1
	isLinkedInLoggedIn = False
	try:
		# check if login was successful
		driver.get("https://www.linkedin.com/mynetwork/import-contacts/")
		time.sleep(2)
		confirmLogIn = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="nav-settings__dropdown-trigger"]/div/li-icon')))
		isLinkedInLoggedIn = True
		print("LinkedIn login for "+linkedinUsername+" was successful")
	except Exception as e:
		print("LinkedIn login for "+linkedinUsername+" failed")
		isLinkedInLoggedIn = False
		if nextLinkedInCredIndex < len(linkedin_credentials):
			logout_from_linkedin(driver)
			select_different_linked_in_account(nextLinkedInCredIndex)
		else:
			print("No more linkedIn accounts available")

	try:
		while isLinkedInLoggedIn and nextEmailCredIndex < len(email_credentials):
			print(email_credentials[nextEmailCredIndex]['username'])
			# switch_to_diff_account(driver, nextEmailCredIndex)
			nextEmailCredIndex += 1
	except Exception as e:
		print(e)
		payload = {
			"driver": driver,
			"exception": e,
			"redirected_url": driver.current_url,
			"request_data": {
				"emailUsername": email_credentials[nextEmailCredIndex]['username'],
				"emailPassword": email_credentials[nextEmailCredIndex]['password'],
				"linkedinUsername": linkedinUsername,
				"linkedinPassword": linkedinPassword,
			},
		}
		pass


# LogIn function for LinkedIn Account
def login_to_linkedin(driver, username, password):
	print("Logging In into linkedIn as "+username)
	try:
		driver.get("https://www.linkedin.com/login")
		user = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "username")))
		user.send_keys(username)
		pwd = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "password")))
		pwd.send_keys(password)
		# submit_form
		login = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="app__container"]/main/div/form/div[3]/button')))
		login.click()
	except Exception as e:
		payload = {
			"driver": driver,
			"exception": e,
			"redirected_url": driver.current_url,
			"request_data": {
				"username": username,
				"password": password,
			},
		}
		print("Page elements were not found")


# LogOut function for LinkedIn Account
def logout_from_linkedin(driver):
	print("Logging out from linkedIn")
	try:
		driver.get("https://www.linkedin.com/mynetwork/import-contacts/")
		# Logout drop down
		clk = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="nav-settings__dropdown-trigger"]')))
		clk.click()
		# Logout
		logout = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="nav-settings__dropdown-options"]/li[5]/ul/li')))
		logout.click()
	except Exception as e:
		payload = {
			"driver": driver,
			"exception": e,
			"redirected_url": driver.current_url,
			"request_data": [],
		}
		print(e)
	# End Driver
	driver.close()
